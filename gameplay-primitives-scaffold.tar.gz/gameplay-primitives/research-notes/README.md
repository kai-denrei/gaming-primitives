Scratch space for agents. Each agent appends to or creates files here per their prompt:

- `discovery-log.md` — running log of Discovery passes per bucket
- `discovery-{bucket}-{date}.md` — per-pass discovery notes
- `research-log.md` — one line per researched primitive
- `needs-review.md` — `[NEEDS VERIFICATION]` flags from Research agents
- `collapse-proposal-{date}.md` — merge/split proposals from Collapse agent
- `collapse-log.md` — history of approved/rejected collapse proposals
- `taxonomy-update-{date}.md` — diff summaries from Taxonomy agent
- `build-log.md` — one line per built mini-game
- `coverage.md` — saturation flags per era bucket
