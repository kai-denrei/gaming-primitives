#!/usr/bin/env bash
# Regenerate mini-games/index.html by scanning primitives/*/minigame/index.html.
# Run from repo root: bash mini-games/regenerate-gallery.sh

set -euo pipefail

repo_root="$(cd "$(dirname "$0")/.." && pwd)"
out="$repo_root/mini-games/index.html"

cards=""
for stub in "$repo_root"/primitives/*/stub.md; do
  id="$(basename "$(dirname "$stub")")"
  mg="$repo_root/primitives/$id/minigame/index.html"
  [ -f "$mg" ] || continue

  # Extract name and verb from stub.md frontmatter.
  name=$(awk '/^name:/{$1=""; gsub(/^[ \t]+|[ \t]+$/,""); print; exit}' "$stub")
  verb=$(awk '/^player_verb:/{$1=""; gsub(/^[ \t]+|[ \t]+$/,""); gsub(/^"|"$/,""); print; exit}' "$stub")

  cards+="<a class=\"card\" href=\"../primitives/$id/minigame/index.html\"><h2>$name</h2><p>$verb</p></a>"$'\n'
done

if [ -z "$cards" ]; then
  cards='<p class="empty">No mini-games built yet. Run the Build wave (see CLI-RUNBOOK.md).</p>'
fi

cat > "$out" <<HTML
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Gameplay Primitives — Gallery</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    body { font-family: system-ui, -apple-system, sans-serif; max-width: 960px; margin: 2rem auto; padding: 0 1rem; line-height: 1.5; }
    h1 { font-size: 1.4rem; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; }
    .card { border: 1px solid #ccc; padding: 1rem; border-radius: 8px; display: block; }
    .card h2 { font-size: 1rem; margin: 0 0 .5rem 0; }
    .card p { margin: 0; color: #555; font-size: .9rem; }
    a { color: inherit; text-decoration: none; }
    a:hover { text-decoration: underline; }
    .empty { color: #999; font-style: italic; }
  </style>
</head>
<body>
  <h1>Gameplay Primitives — Mini-Games</h1>
  <p>One playable per primitive. Source readable. Educational.</p>
  <div class="grid">
$cards
  </div>
</body>
</html>
HTML

echo "Regenerated $out"
