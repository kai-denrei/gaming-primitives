This directory will contain `primitives/{id}/` folders, one per primitive. Each subfolder has:

- `stub.md` (seed, written by Discovery agent)
- `research.md` (deep, written by Research agent)
- `spec.md` (buildable spec, written by Spec agent)
- `minigame/` (working browser game, written by Build agent)

See `../schema.md` for shapes and `../agent-prompts/` for the agents that fill these in.
